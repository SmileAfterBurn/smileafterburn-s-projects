export enum Region {
  MYKOLAIV = 'Миколаївська',
  KHERSON = 'Херсонська',
  ODESA = 'Одеська'
}

export enum ServiceType {
  FOOD = 'Продукти харчування',
  MEDICAL = 'Медична допомога',
  EVACUATION = 'Евакуація',
  LEGAL = 'Юридична допомога',
  SHELTER = 'Прихисток (Житло)',
  PSYCHOLOGICAL = 'Психологічна підтримка',
  HYGIENE = 'Засоби гігієни'
}

export interface Organization {
  id: string;
  name: string;
  description: string;
  region: Region;
  services: ServiceType[];
  location: {
    lat: number;
    lng: number;
  };
  contacts: {
    phone: string;
    email: string;
    website?: string;
  };
}

export interface MapViewport {
  center: {
    lat: number;
    lng: number;
  };
  zoom: number;
}

export enum AppStep {
  REGION_SELECT = 0,
  SERVICE_SELECT = 1,
  CONFIRMATION = 2,
  MAP_VIEW = 3
}