import { Organization, Region, ServiceType, MapViewport } from './types';

// NOTE: Replace this with a valid Google Maps API Key for the map to render correctly.
export const GOOGLE_MAPS_API_KEY = 'YOUR_API_KEY_HERE'; 

export const GOOGLE_SHEETS_URL = 'https://docs.google.com/spreadsheets/d/1BxiMvs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit'; // Placeholder link

export const REGION_VIEWPORTS: Record<Region, MapViewport> = {
  [Region.MYKOLAIV]: {
    center: { lat: 47.2, lng: 32.0 },
    zoom: 9
  },
  [Region.KHERSON]: {
    center: { lat: 46.6, lng: 33.0 },
    zoom: 9
  },
  [Region.ODESA]: {
    center: { lat: 46.8, lng: 30.5 },
    zoom: 8
  }
};

export const INITIAL_VIEWPORT: MapViewport = {
  center: { lat: 46.9, lng: 31.5 }, // Centered between the 3 regions
  zoom: 7
};

export const MOCK_ORGANIZATIONS: Organization[] = [
  {
    id: '1',
    name: 'Червоний Хрест Миколаїв',
    description: 'Гуманітарна допомога та підтримка населення.',
    region: Region.MYKOLAIV,
    services: [ServiceType.FOOD, ServiceType.MEDICAL, ServiceType.HYGIENE],
    location: { lat: 46.975, lng: 31.9946 },
    contacts: { phone: '+380512000001', email: 'mk@redcross.org.ua' }
  },
  {
    id: '2',
    name: 'Волонтери Херсона',
    description: 'Евакуація та допомога з водою.',
    region: Region.KHERSON,
    services: [ServiceType.EVACUATION, ServiceType.FOOD, ServiceType.SHELTER],
    location: { lat: 46.6354, lng: 32.6169 },
    contacts: { phone: '+380990000002', email: 'help@khersonvolunteers.org' }
  },
  {
    id: '3',
    name: 'Одеса Хелп',
    description: 'Юридична та психологічна допомога ВПО.',
    region: Region.ODESA,
    services: [ServiceType.LEGAL, ServiceType.PSYCHOLOGICAL, ServiceType.SHELTER],
    location: { lat: 46.4825, lng: 30.7233 },
    contacts: { phone: '+380480000003', email: 'info@odesahelp.org' }
  },
  {
    id: '4',
    name: 'Карітас Південь',
    description: 'Багатопрофільна допомога для сімей.',
    region: Region.MYKOLAIV,
    services: [ServiceType.FOOD, ServiceType.PSYCHOLOGICAL],
    location: { lat: 46.96, lng: 32.01 },
    contacts: { phone: '+380512000004', email: 'contact@caritas.ua' }
  },
  {
    id: '5',
    name: 'Єдність (Одеса)',
    description: 'Медикаменти та одяг.',
    region: Region.ODESA,
    services: [ServiceType.MEDICAL, ServiceType.HYGIENE],
    location: { lat: 46.47, lng: 30.74 },
    contacts: { phone: '+380480000005', email: 'unity@odesa.ua' }
  }
];