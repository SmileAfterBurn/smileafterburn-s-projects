import React from 'react';
import { Organization } from '../types';

interface DetailsPanelProps {
  organization: Organization | null;
  onClose: () => void;
}

const DetailsPanel: React.FC<DetailsPanelProps> = ({ organization, onClose }) => {
  if (!organization) return null;

  const handleEmailClick = () => {
    const subject = encodeURIComponent(`Запит на допомогу: ${organization.name}`);
    window.location.href = `mailto:${organization.contacts.email}?subject=${subject}`;
    
    // Using a small timeout to simulate the prompt after action, 
    // as we cannot easily intercept the mailto opening event in a pure frontend way reliably without blocking.
    // A standard browser confirm dialog is used here for simplicity and robustness.
    setTimeout(() => {
      const call = window.confirm(`Ви надіслали лист. Бажаєте також зателефонувати?`);
      if (call) {
        window.location.href = `tel:${organization.contacts.phone}`;
      }
    }, 1000);
  };

  return (
    <div className="absolute bottom-0 left-0 right-0 md:top-4 md:right-4 md:left-auto md:bottom-auto z-20 p-4 md:max-w-sm w-full">
      <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-200 animate-fade-in-up">
        <div className="bg-blue-600 p-4 text-white flex justify-between items-start">
          <div>
            <h3 className="font-bold text-lg">{organization.name}</h3>
            <span className="text-xs bg-blue-500 px-2 py-1 rounded-full mt-1 inline-block">
              {organization.region}
            </span>
          </div>
          <button 
            onClick={onClose}
            className="text-white/80 hover:text-white transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-gray-600 text-sm leading-relaxed">
            {organization.description}
          </p>

          <div>
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Послуги</h4>
            <div className="flex flex-wrap gap-2">
              {organization.services.map((service, idx) => (
                <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-md border border-gray-200">
                  {service}
                </span>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-gray-100 space-y-3">
            <button
              onClick={() => window.location.href = `tel:${organization.contacts.phone}`}
              className="w-full flex items-center justify-center gap-2 bg-green-50 hover:bg-green-100 text-green-700 py-3 rounded-xl transition-colors font-medium"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              {organization.contacts.phone}
            </button>

            <button
              onClick={handleEmailClick}
              className="w-full flex items-center justify-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 py-3 rounded-xl transition-colors font-medium"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              Написати листа
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailsPanel;