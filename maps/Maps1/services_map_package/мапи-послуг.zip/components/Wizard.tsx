import React from 'react';
import { Region, ServiceType, AppStep } from '../types';
import { GOOGLE_SHEETS_URL } from '../constants';

interface WizardProps {
  step: AppStep;
  selectedRegion: Region | null;
  selectedServices: ServiceType[];
  onRegionSelect: (region: Region) => void;
  onServiceToggle: (service: ServiceType) => void;
  onConfirmServices: () => void;
  onFinishDecision: (stayOnMap: boolean) => void;
}

const Wizard: React.FC<WizardProps> = ({
  step,
  selectedRegion,
  selectedServices,
  onRegionSelect,
  onServiceToggle,
  onConfirmServices,
  onFinishDecision
}) => {
  if (step === AppStep.MAP_VIEW) return null;

  return (
    <div className="absolute inset-0 bg-black/40 backdrop-blur-sm z-10 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-fade-in">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-400 to-blue-500 h-2 w-full"></div>
        <div className="p-8">
          
          {/* Step 0: Region Selection */}
          {step === AppStep.REGION_SELECT && (
            <>
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Вітаю!</h2>
              <p className="text-gray-600 mb-6">Де саме необхідна допомога?</p>
              
              <div className="grid gap-3">
                {Object.values(Region).map((region) => (
                  <button
                    key={region}
                    onClick={() => onRegionSelect(region)}
                    className="group flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all duration-200"
                  >
                    <span className="font-medium text-gray-700 group-hover:text-blue-700">{region}</span>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-300 group-hover:text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                ))}
              </div>
            </>
          )}

          {/* Step 1: Service Selection */}
          {step === AppStep.SERVICE_SELECT && (
            <>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded font-bold uppercase">{selectedRegion}</span>
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Який вид допомоги вам потрібен?</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8 max-h-[40vh] overflow-y-auto pr-2">
                {Object.values(ServiceType).map((service) => {
                  const isSelected = selectedServices.includes(service);
                  return (
                    <button
                      key={service}
                      onClick={() => onServiceToggle(service)}
                      className={`text-left p-3 rounded-lg border transition-all duration-200 flex items-start gap-3 ${
                        isSelected 
                          ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 ${
                        isSelected ? 'bg-blue-500 border-blue-500' : 'border-gray-300 bg-white'
                      }`}>
                        {isSelected && (
                          <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
                          </svg>
                        )}
                      </div>
                      <span className={`text-sm ${isSelected ? 'text-blue-900 font-medium' : 'text-gray-700'}`}>
                        {service}
                      </span>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={onConfirmServices}
                disabled={selectedServices.length === 0}
                className={`w-full py-4 rounded-xl font-bold text-lg transition-all transform active:scale-[0.98] ${
                  selectedServices.length > 0
                    ? 'bg-blue-600 text-white shadow-lg hover:bg-blue-700 hover:shadow-xl'
                    : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                }`}
              >
                Підтверджую
              </button>
            </>
          )}

          {/* Step 2: Confirmation / Route Decision */}
          {step === AppStep.CONFIRMATION && (
            <>
               <div className="text-center py-4">
                <div className="w-16 h-16 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="text-xl font-bold text-gray-800 mb-2">Пошук завершено</h2>
                <p className="text-gray-600 mb-8">
                  Ми знайшли організації за вашими критеріями.
                </p>

                <div className="space-y-3">
                  <button
                    onClick={() => onFinishDecision(true)}
                    className="w-full py-3 px-4 bg-white border-2 border-blue-600 text-blue-600 rounded-xl font-bold hover:bg-blue-50 transition-colors flex items-center justify-center gap-2"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0121 18.382V7.618a1 1 0 01-.553-.894L15 7m0 13V7" />
                    </svg>
                    Залишитись на карті
                  </button>

                  <div className="relative flex py-2 items-center">
                    <div className="flex-grow border-t border-gray-200"></div>
                    <span className="flex-shrink-0 mx-4 text-gray-400 text-xs uppercase">або</span>
                    <div className="flex-grow border-t border-gray-200"></div>
                  </div>

                  <button
                    onClick={() => onFinishDecision(false)}
                    className="w-full py-3 px-4 bg-green-600 text-white rounded-xl font-bold shadow-md hover:bg-green-700 hover:shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                    Перейти в Google Sheets
                  </button>
                  <p className="text-xs text-gray-400 mt-2">
                    Таблиця містить повний список та фільтри
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Wizard;