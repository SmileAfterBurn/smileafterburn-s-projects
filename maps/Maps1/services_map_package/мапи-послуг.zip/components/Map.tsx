import React, { useEffect, useRef, useState } from 'react';
import { Organization, MapViewport } from '../types';
import { loadGoogleMapsScript } from '../services/mapLoader';
import { GOOGLE_MAPS_API_KEY } from '../constants';

interface MapProps {
  viewport: MapViewport;
  organizations: Organization[];
  onMarkerClick: (org: Organization) => void;
}

const Map: React.FC<MapProps> = ({ viewport, organizations, onMarkerClick }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const [scriptError, setScriptError] = useState<boolean>(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (GOOGLE_MAPS_API_KEY === 'YOUR_API_KEY_HERE') {
      setScriptError(true);
      return;
    }

    loadGoogleMapsScript()
      .then(() => {
        setLoaded(true);
      })
      .catch(() => {
        setScriptError(true);
      });
  }, []);

  // Initialize Map
  useEffect(() => {
    if (loaded && mapRef.current && !googleMapRef.current) {
      googleMapRef.current = new (window as any).google.maps.Map(mapRef.current, {
        center: viewport.center,
        zoom: viewport.zoom,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
        zoomControl: true,
        styles: [
          {
            featureType: 'poi',
            elementType: 'labels',
            stylers: [{ visibility: 'off' }],
          },
        ],
      });
    }
  }, [loaded, viewport]);

  // Update Viewport
  useEffect(() => {
    if (googleMapRef.current) {
      googleMapRef.current.panTo(viewport.center);
      googleMapRef.current.setZoom(viewport.zoom);
    }
  }, [viewport]);

  // Manage Markers
  useEffect(() => {
    if (!googleMapRef.current) return;

    // Clear existing markers
    markersRef.current.forEach((marker) => marker.setMap(null));
    markersRef.current = [];

    // Add new markers
    organizations.forEach((org) => {
      const marker = new (window as any).google.maps.Marker({
        position: org.location,
        map: googleMapRef.current,
        title: org.name,
        animation: (window as any).google.maps.Animation.DROP,
      });

      marker.addListener('click', () => {
        onMarkerClick(org);
      });

      markersRef.current.push(marker);
    });
  }, [organizations, onMarkerClick]);

  if (scriptError || GOOGLE_MAPS_API_KEY === 'YOUR_API_KEY_HERE') {
    return (
      <div className="w-full h-full bg-gray-100 flex flex-col items-center justify-center text-center p-6">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-red-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Map Configuration Required</h3>
          <p className="text-gray-600 mb-4">
            To view the map, you must provide a valid Google Maps API Key in <code>constants.ts</code>.
          </p>
          <p className="text-sm text-gray-400">
            (Current Key: {GOOGLE_MAPS_API_KEY})
          </p>
        </div>
      </div>
    );
  }

  return <div ref={mapRef} className="w-full h-full" />;
};

export default Map;