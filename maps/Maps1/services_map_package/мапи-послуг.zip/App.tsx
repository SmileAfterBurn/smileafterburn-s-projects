import React, { useState, useMemo, useCallback } from 'react';
import Map from './components/Map';
import Wizard from './components/Wizard';
import DetailsPanel from './components/DetailsPanel';
import { 
  Region, 
  ServiceType, 
  Organization, 
  AppStep, 
  MapViewport 
} from './types';
import { 
  INITIAL_VIEWPORT, 
  REGION_VIEWPORTS, 
  MOCK_ORGANIZATIONS, 
  GOOGLE_SHEETS_URL 
} from './constants';

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>(AppStep.REGION_SELECT);
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);
  const [selectedServices, setSelectedServices] = useState<ServiceType[]>([]);
  const [viewport, setViewport] = useState<MapViewport>(INITIAL_VIEWPORT);
  const [selectedOrg, setSelectedOrg] = useState<Organization | null>(null);

  // Filter Logic
  const filteredOrgs = useMemo(() => {
    let orgs = MOCK_ORGANIZATIONS;

    // If we are in the wizard, we might not want to show everything yet,
    // but to keep the map interesting, we can show all or filter progressively.
    // Requirement says: "Markers appear after confirmation".
    if (step !== AppStep.MAP_VIEW) {
      return []; // Hide markers until confirmed
    }

    if (selectedRegion) {
      orgs = orgs.filter(o => o.region === selectedRegion);
    }

    if (selectedServices.length > 0) {
      orgs = orgs.filter(o => 
        o.services.some(s => selectedServices.includes(s))
      );
    }

    return orgs;
  }, [step, selectedRegion, selectedServices]);

  // Handlers
  const handleRegionSelect = (region: Region) => {
    setSelectedRegion(region);
    // Zoom to region immediately
    setViewport(REGION_VIEWPORTS[region]);
    setStep(AppStep.SERVICE_SELECT);
  };

  const handleServiceToggle = (service: ServiceType) => {
    setSelectedServices(prev => {
      if (prev.includes(service)) {
        return prev.filter(s => s !== service);
      }
      return [...prev, service];
    });
  };

  const handleConfirmServices = () => {
    setStep(AppStep.CONFIRMATION);
  };

  const handleFinishDecision = (stayOnMap: boolean) => {
    if (stayOnMap) {
      setStep(AppStep.MAP_VIEW);
    } else {
      window.open(GOOGLE_SHEETS_URL, '_blank');
      // Optionally stay on map step after opening link, or reset
      setStep(AppStep.MAP_VIEW);
    }
  };

  const handleMarkerClick = useCallback((org: Organization) => {
    setSelectedOrg(org);
  }, []);

  const handleReset = () => {
    setStep(AppStep.REGION_SELECT);
    setSelectedRegion(null);
    setSelectedServices([]);
    setSelectedOrg(null);
    setViewport(INITIAL_VIEWPORT);
  };

  return (
    <div className="relative w-screen h-screen bg-gray-100 overflow-hidden">
      {/* Main Map */}
      <Map 
        viewport={viewport}
        organizations={filteredOrgs}
        onMarkerClick={handleMarkerClick}
      />

      {/* Wizard Overlay */}
      <Wizard 
        step={step}
        selectedRegion={selectedRegion}
        selectedServices={selectedServices}
        onRegionSelect={handleRegionSelect}
        onServiceToggle={handleServiceToggle}
        onConfirmServices={handleConfirmServices}
        onFinishDecision={handleFinishDecision}
      />

      {/* Details Panel (Slide over) */}
      <DetailsPanel 
        organization={selectedOrg}
        onClose={() => setSelectedOrg(null)}
      />

      {/* Reset Button (Visible on Map View) */}
      {step === AppStep.MAP_VIEW && (
        <button
          onClick={handleReset}
          className="absolute top-4 left-4 z-10 bg-white p-3 rounded-xl shadow-md text-gray-600 hover:text-blue-600 hover:bg-blue-50 transition-all font-medium flex items-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          <span className="hidden md:inline">Почати спочатку</span>
        </button>
      )}

      {/* Link to Sheets Button (Always accessible on Map View) */}
      {step === AppStep.MAP_VIEW && (
        <button
            onClick={() => window.open(GOOGLE_SHEETS_URL, '_blank')}
            className="absolute top-4 right-14 z-10 bg-green-600 p-3 rounded-xl shadow-md text-white hover:bg-green-700 transition-all font-medium flex items-center gap-2"
            title="Відкрити базу даних (Google Sheets)"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <span className="hidden md:inline">База даних</span>
        </button>
      )}
    </div>
  );
};

export default App;