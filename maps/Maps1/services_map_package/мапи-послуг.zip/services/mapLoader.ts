import { GOOGLE_MAPS_API_KEY } from '../constants';

let isLoading = false;
let isLoaded = false;

export const loadGoogleMapsScript = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (isLoaded) {
      resolve();
      return;
    }
    if (isLoading) {
      // Simple polling if already loading to avoid multiple script tags
      const check = setInterval(() => {
        if (isLoaded) {
          clearInterval(check);
          resolve();
        }
      }, 100);
      return;
    }

    if ((window as any).google && (window as any).google.maps) {
      isLoaded = true;
      resolve();
      return;
    }

    isLoading = true;
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places,geometry`;
    script.async = true;
    script.defer = true;
    script.onload = () => {
      isLoaded = true;
      isLoading = false;
      resolve();
    };
    script.onerror = (err) => {
      isLoading = false;
      reject(err);
    };
    document.head.appendChild(script);
  });
};